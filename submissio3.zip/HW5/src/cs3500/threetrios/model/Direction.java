package cs3500.threetrios.model;

/**
 * Enum that represents the possible directions of a cards attack value.
 */
public enum Direction {
  NORTH, EAST, SOUTH, WEST
}
