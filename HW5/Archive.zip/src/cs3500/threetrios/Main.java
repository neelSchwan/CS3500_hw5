package cs3500.threetrios;

import cs3500.threetrios.model.GameModel;
import cs3500.threetrios.model.ThreeTriosModel;
import cs3500.threetrios.view.ThreeTriosGameGUIView;
import cs3500.threetrios.view.ThreeTriosView;

public class Main {

  public static void main(String[] args) {
    //Console

    //GUI
    GameModel model = new ThreeTriosModel();
    ThreeTriosView view = new ThreeTriosGameGUIView();
    TicTacToeController controller = new TicTacToeGUIController(view);
    controller.playGame(model);
  }
}
