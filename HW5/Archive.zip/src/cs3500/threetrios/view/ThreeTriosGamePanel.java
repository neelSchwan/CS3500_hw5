package cs3500.threetrios.view;

import javax.swing.JPanel;

public class ThreeTriosGamePanel extends JPanel implements ThreeTriosPanel {

}
