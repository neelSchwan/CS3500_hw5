package cs3500.threetrios.view;

public interface ThreeTriosPanel {
}
